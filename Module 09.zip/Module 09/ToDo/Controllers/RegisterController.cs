﻿using Microsoft.AspNetCore.Mvc;
using System;
using ToDoApp.Data;
using ToDoApp.Models;
using Microsoft.EntityFrameworkCore;

namespace ToDoApp.Controllers
{
    public class RegirsterationController : Controller
    {
        private TicketContext context;
        public RegirsterationController(TicketContext ctx) => context = ctx;

        [HttpGet]
        public IActionResult Index() => View();

        [HttpPost]
        public IActionResult Index(User user)
        {
            if (TempData["okEmail"] == null)
            {
                string msg = Check.EmailExists(context, user.EmailAddress);
                if (!string.IsNullOrEmpty(msg))
                {
                    ModelState.AddModelError(nameof(user.EmailAddress), msg);
                }
            }

            if (ModelState.IsValid)
            {
                context.Users.Add(user);
                context.SaveChanges();
                return RedirectToAction("Welcome");
            }
            else
            {
                return View(user);
            }
        }

        [HttpGet]
        public IActionResult Welcome(User user)
        {
            return View();
        }
    }
}